import React from 'react'

const BrandSettingsModal = () => {
  return (
    <div>This is Modal</div>
  )
}

export default BrandSettingsModal