export const AddnewStyle = { 
  borderRadius: '8px', 
  padding: '14px, 20px, 14px, 20px',
  height: '48px',
  width: '180px',

}
export const AddnewSettingsStyle = { 
  borderRadius: '8px', 
  padding: '14px, 20px, 14px, 20px',
  height: '48px',
  width: '220px',

}

export const footerStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'end',
}

export const submitStyle = {
  width: '180px',
  height: '56px',
  padding: '8px, 16px, 8px, 16px',
  radius: '4px',
  marginTop: '16px',
}