// remning works related props 
// import React from 'react'
// import CustomModal from './CustomModal'
// import CustomButton from './CustomButton'

// const CustomDeleteDialog = ({message,subtitle}) => {
//   return (
//     <CustomModal
//     isModalOpen={isModalOpen}
//         handleOk={handleOk}
//         handleCancel={handleCancel} 
//         title={''}
//         width={400}
//         footer={[
//           <div style={{
//             display: 'flex',
//             alignItems: 'center',
//             justifyContent: 'end',
//           }}>
//             <CustomButton
//               Text={'Yes'}
//               onClickHandler={handleOk}
//             style={{
//                 width: '100px',
//                 height: '56px',
//                 padding: '8px, 16px, 8px, 16px',
//                 radius: '4px',
//                 marginTop: '16px',
//             }}
//             />
//              <CustomButton
//               Text={'No'}
//               onClickHandler={handleOk}
//             style={{
//                 width: '100px',
//                 height: '56px',
//                 padding: '8px, 16px, 8px, 16px',
//                 radius: '4px',
//                 marginTop: '16px',
//             }}
//             />
//           </div>
//         ]}
//     >
//          <h1>{message}</h1>
//          <h2>{subtitle}</h2>
//     </CustomModal>
//   )
// }

// export default CustomDeleteDialog